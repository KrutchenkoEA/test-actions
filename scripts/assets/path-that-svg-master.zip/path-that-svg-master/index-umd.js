import pathThatSvg from './index'
export default pathThatSvg
