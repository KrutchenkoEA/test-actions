import svgson, { svgsonSync } from './svgson'
import stringify from './stringify'
export default svgson
export { stringify, svgson as parse, svgsonSync as parseSync }
